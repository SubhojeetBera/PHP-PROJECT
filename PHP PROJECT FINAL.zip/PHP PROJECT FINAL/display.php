<html>
<head>
<style>
table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  padding: 8px;
  text-align: left;
  border-bottom: 1px solid #ddd;
}

tr:hover {background-color: coral;}
</style>
</head><body style="background-image:url('1.jpg');background-repeat: no-repeat;
    background-size: cover;
    background-position:;
    width: 100%;
    height: 100%;">
<?php
$servername="localhost";
$username="root";
$password="";
$db="college";
$table="student_info";
$connection=mysql_connect($servername,$username);
//$result=mysql_select_db($db) or die("database could not be selected);
//$query="SELECT * FROM $table;
//$result=mysql_query($query);
mysql_select_db("$db",$connection);
$result=mysql_query("SELECT * FROM $table");
$num_rows=mysql_num_rows($result);
//mysql_query()_execute the query
echo "<h1><center><font color=white>Student Database</font></center></h1>";
echo "<table bgcolor=#ffffb3 border=2 align=center width=50% cellpadding=10px>";
echo "<tr>";
echo "<th><center><font color=red><b>Roll</b></center></th>";
echo "<th><center><font color=red><b>Name</b></center></th>";
echo "<td><center><font color=red><b>Email</b></center></td>";
echo "<td><center><font color=red><b>Mobile_No</b></center></td>";
echo "<td><center><font color=red><b>Course</b></center></td>";
echo "<td><center><font color=red><b>Address</b></center></td>";
echo "</tr>";
while($row=mysql_fetch_array($result))
{
echo "<tr align=center>\n";
echo "<td>".$row["roll"]."</td>";
echo "<td>".$row["name"]."</td>";
echo "<td>".$row["email"]."</td>";
echo "<td>".$row["mobile_no"]."</td>";
echo "<td>".$row["course"]."</td>";
echo "<td>".$row["address"]."</td>";
echo"</tr>";
}
echo "</table>";
?>
<h1><a style="float:left;color:white"href="welcome.php">Go to Student Dashboard</a></h1>
</body></html>