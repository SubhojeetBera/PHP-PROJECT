<html><body style="background-image:url('1.jpg');background-repeat: no-repeat;
    background-size: cover;
    background-position:;
    width: 100%;
    height: 100%;">
<form action="selectquery2.php" method="POST">
<center>
<h1><center><font color=white><u>Search Your Data</u></font></center></h1>
<br><br>
<table border=0>
<tr>
<th><font size=5 color=white>Enter Roll No To be Show:</font></th>
<td><input type="text" name="roll"></td>
</tr>
<tr>
<td></td>
<td><input type="submit" value="Search">
<input type="reset"></td>
</tr>
</center>
</form>
<h1><a style="float:left;"href="welcome2.php"><b style="color:white">Go to Result Dashboard</b></a></h1>
</body></html>
