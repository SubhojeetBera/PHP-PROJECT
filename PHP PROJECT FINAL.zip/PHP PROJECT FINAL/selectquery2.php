<?php
$con=mysql_connect("localhost","root");
if(!$con)
{
die('could not connect.'.mysql_error());
}
mysql_select_db("college",$con);
$result=mysql_query("SELECT * FROM class_result where roll='$_POST[roll]'");
$num_rows=mysql_num_rows($result);
if($num_rows>=1)
{
echo "<table border='1'>
<tr>
<th>Roll</th>
<th>Name</th>
<th>Module 1</th>
<th>Module 2</th>
<th>Module 3</th>
<th>Module 4</th>
<th>Module 5</th>
<th>Total</th>
<th>Grade</th>
</tr>";
while($row=mysql_fetch_array($result))
{
echo"<tr>";
echo"<td>".$row['roll']."</td>";
echo"<td>".$row['name']."</td>";
echo"<td>".$row['mod1']."</td>";
echo"<td>".$row['mod2']."</td>";
echo"<td>".$row['mod3']."</td>";
echo"<td>".$row['mod4']."</td>";
echo"<td>".$row['mod5']."</td>";
echo"<td>".$row['total']."</td>";
echo"<td>".$row['grade']."</td>";
echo"</tr>";
}
echo"</table>";
}
else
echo "record not found";
mysql_close($con);
?>
<html><body><h1><a style="float:left;"href="search4.php">Go to Result Dashboard</a></h1>
</html></body>