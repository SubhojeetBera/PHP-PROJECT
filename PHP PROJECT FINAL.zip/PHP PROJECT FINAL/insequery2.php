<?php
$con=mysql_connect("localhost","root");
if(!$con)
{
die('Could not connect:'.mysql_error());
}
mysql_select_db("college",$con);
$sql="INSERT INTO class_result(roll,name,mod1,mod2,mod3,mod4,mod5,total,grade)VALUES('$_POST[roll]','$_POST[name]','$_POST[mod1]','$_POST[mod2]','$_POST[mod3]','$_POST[mod4]','$_POST[mod5]','$_POST[total]','$_POST[grade]')";
if(!mysql_query($sql,$con))
{
die('Error:'.mysql_error());
}
echo"1 record added";
mysql_close($con)
?>
<html><body><a href="welcome2.php">Go bake to home page</a>
</body></html>