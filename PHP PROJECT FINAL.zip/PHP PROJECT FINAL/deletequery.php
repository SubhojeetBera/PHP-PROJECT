<?php
$con=mysql_connect("localhost","root");
if(!$con)
{
die('could cot connect:'.mysql_error());
}
mysql_select_db("college",$con);
$sql="DELETE FROM student_info WHERE roll=$_POST[roll]";
if(!mysql_query($sql,$con))
{
die('Error:'.mysql_error());
}
echo"record deleted sucessfully";
mysql_close($con)
?>
<html><body><a href="welcome.php">Go bake to home page</a>
</body></html>