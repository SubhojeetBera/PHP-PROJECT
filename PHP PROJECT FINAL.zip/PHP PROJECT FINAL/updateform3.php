<html><body>
<form action="updatequery2.php" method="POST">
<center>
<font size=5 color="blue"><u>Update your data</u></font>
<br><br>
<?php
$con=mysql_connect("localhost","root");
if(!$con)
{
die('could cot connect:'.mysql_error());
}
mysql_select_db("college",$con);
$result=mysql_query("select * from class_result where roll=$_POST[roll]");
$num_rows=mysql_num_rows($result);
if($num_rows>=1)
{
echo "<table border='1'>
<tr>
<th>Roll</th>
<th>Name</th>
<th>Module I</th>
<th>Module II</th>
<th>Module III</th>
<th>Module IV</th>
<th>Module V</th>
<th>Total</th>
<th>Grade </th>
</tr>";
while($row=mysql_fetch_array($result))
{
$flag=1;
echo "<tr align=center>\n";
echo "<td>".$row["roll"]."</td>";
echo "<td>".$row["name"]."</td>";
echo "<td>".$row["mod1"]."</td>";
echo "<td>".$row["mod2"]."</td>";
echo "<td>".$row["mod3"]."</td>";
echo "<td>".$row["mod4"]."</td>";
echo "<td>".$row["mod5"]."</td>";
echo "<td>".$row["total"]."</td>";
echo "<td>".$row["grade"]."</td>";
echo"</tr>";
}
echo"</table>";
}
else
echo "record not found";
mysql_close($con);
?>
<table border=0>
<tr>
<td>Roll:</td>
<td><input type="text" name="roll"</td>
</tr>
<tr>
<td> Name:</td>
<td><input type="text" name="name"</td>
</tr>
<tr>
<td>Module I:</td>
<td><input type="text" name="mod1"</td>
</tr>
<tr>
<td>Module II:</td>
<td><input type="text" name="mod2"</td>
</tr>
<tr>
<td> Module III:</td>
<td><input type="text" name="mod3"</td>
</tr>
<tr>
<td>Module IV:</td>
<td><input type="text" name="mod4"</td>
</tr>
<tr>
<td>Module V:</td>
<td><input type="text" name="mod5"</td>
</tr>
<tr>
<td>Total:</td>
<td><input type="text" name="total"</td>
</tr>
<tr>
<td>Grade:</td>
<td><input type="text" name="grade"</td>
</tr>
<tr>
<td></td>
<td><input type="submit" value="update">
<input type="reset"></td>
</tr>
</center>
</table>
</form>
<h1><a style="float:left;"href="welcome2.php">Go to Result Dashboard</a></h1>
</body>
</html>