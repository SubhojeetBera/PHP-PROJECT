<?php
include 'conn.php';
session_start();
if(isset($_POST["submit"]))
{
$_SESSION["user"]=$_POST["user"];
$_SESSION["pass"]=$_POST["pass"];
$_SESSION["desig"]=$_POST["desig"];
$_SESSION['last_time']=time();
{
if(!empty($_POST['user'])&& !empty($_POST['pass'])&& !empty($_POST['desig']))
{
$user=$_POST['user'];
$pass=$_POST['pass'];
$desig=$_POST['desig'];
$query=mysqli_query($conn,"SELECT * FROM login where user='".$user."' AND pass='".$pass."' AND desig='".$desig."'");
$numrows=mysqli_num_rows($query);
if($numrows!=0)
{
while($row=mysqli_fetch_assoc($query))
{
$username=$row['user'];
$password=$row['pass'];
$designation=$row['desig'];
}
if($user==$username && $pass==$password && $desig==$designation)
{
    if($user==$username && $pass==$password && $desig=="Admin")
    {
    header('location: welcome.php');
    }
    elseif($user==$username && $pass==$password && $desig=="student")
    {
    header('location: student1.html');
    }
    else
    {
    echo "Invalid username or password!";
    }
//header('location: welcome.php');
}
}
else
{
echo "Invalid username or password!";
}
}
else
{
echo "Required all fields!";
}
}
}
?>
<html>
   
   <head>
      <b><title>Login Page</title></b>
      
      <style type = "text/css">
         body {
            font-family:Arial, Helvetica, sans-serif;
            font-size:14px;
         }
         label {
            font-weight:bold;
            width:100px;
            font-size:14px;
         }
         .box {
            border:#666666 solid 1px;
         }
      </style>
	  </head>
   <h1 style="text-align:center;background-color:white"><marquee  direction="right" behavior="alternate" scrollamount="5">RKMSCC COLLEGE MANAGEMENT SYSTEM</marquee></H1>
   <body background="bg2.jpg" style="background-repeat:no-repeat;background-size:100% 100%">
	
      <div align = "center">
         <div  style = "width:300px; border: solid 1px #333333; " align = "left">
            <div style = "background-color:green; color:white; padding:3px;"><b>LOGIN</b></div>
				
            <div style = "margin:30px">
               
               <h1>User Login</h1>
<form method="post">
<input type=text name="user" class="user" id="user" placeholder="Enter Username" required></br><br/>
<input type="password" name="pass" id="pass" placeholder="Enter Password" required><br><br>
<select name="desig" width=20>
<option value="Admin">Admin</option>
<option value="student">Student</option>
</select>&nbsp;&nbsp;
<input type="submit" name="submit" value="Submit" >&nbsp;<a href="index.html">
<input type="button" name="submit" value="Back" ></a>

</form></div></center>
</header>

				  
               </form>
					 </div>
				
         </div>
			
      </div>

   </body>
</html>