<?php
$con=mysql_connect("localhost","root");
if(!$con)
{
die('Could not connect:'.mysql_error());
}
mysql_select_db("college",$con);
$sql="INSERT INTO login(user,pass,desig)VALUES('$_POST[username]','$_POST[password]','$_POST[desig]')";
if(!mysql_query($sql,$con))
{
die('Error:'.mysql_error());
}
echo"REGISTRATION SUCCESFULL";
mysql_close($con)
?>
