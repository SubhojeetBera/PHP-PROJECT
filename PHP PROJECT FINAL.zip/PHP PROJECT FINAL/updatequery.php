<?php
$con=mysql_connect("localhost","root");
if(!$con)
{
die('Could not connect:'.mysql_error());
}
mysql_select_db("college",$con);
$sql="UPDATE student_info SET roll='$_POST[roll]',name='$_POST[name]',email='$_POST[email]',mobile_no='$_POST[mobile_no]',course='$_POST[course]',address='$_POST[address]' where roll='$_POST[roll]'";
if(!mysql_query($sql,$con))
{
die('Error:'.mysql_error());
}
echo"1 record updated";
mysql_close($con)
?>
<html><body><a href="welcome.php">Go bake to home page</a>
</body></html>