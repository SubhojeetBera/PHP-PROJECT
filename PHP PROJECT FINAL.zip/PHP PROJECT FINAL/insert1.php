<html>
<body style="background-image:url('1.jpg');background-repeat: no-repeat;
    background-size: cover;
    background-position:;
    width: 100%;
    height: 100%;">
<form action="insequery.php" method="post">
<center>
<h1><center><font color=white><u>Insert Data</u></font></center></h1>
<table border=0>
<tr>
<th><font size=5 color=white>Roll:</font></th>
<td><input type="text" name="roll" required></td>
</tr>
<tr>
<th><font size=5 color=white>Name:</font></th>
<td><input type="text" name="name" required</td>
</tr>
<tr>
<th><font size=5 color=white>Email:</font></th>
<td><input type="text" name="email" required</td>
</tr>
<tr>
<th><font size=5 color=white>Mobile_No:</font></th>
<td><input type="text" name="mobile_no" required</td>
</tr>
<tr>
<th><font size=5 color=white>Course:</font></th>
<td><input type="text" name="course" required</td>
</tr>
<tr>
<th><font size=5 color=white>Address:</font></th>
<td><input type="text" name="address" required</td>
</tr>

<tr>
<td></td>
<th><font size=5 color=#ff6666><input type="submit" value="Insert">
<input type="reset"></font></th>
</tr>
</center>
</form>
<h1><a style="float:left;"href="welcome.php"><b style="color:white">Go to Student Dashboard</b></a></h1>
</body>
</html>