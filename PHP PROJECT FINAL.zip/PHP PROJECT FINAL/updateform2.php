<html><body>
<form action="updatequery.php" method="POST">
<center>
<font size=5 color="blue"><u>Update your data</u></font>
<br><br>
<?php
$con=mysql_connect("localhost","root");
if(!$con)
{
die('could cot connect:'.mysql_error());
}
mysql_select_db("college",$con);
$result=mysql_query("select * from student_info where roll=$_POST[roll]");
$num_rows=mysql_num_rows($result);
if($num_rows>=1)
{
echo "<table border='1'>
<tr>
<th>Roll</th>
<th>Name</th>
<th>Email</th>
<th>Mobile_No</th>
<th>Course</th>
<th>Address</th>
</tr>";
while($row=mysql_fetch_array($result))
{
$flag=1;
echo"<tr>";
echo"<td>".$row['roll']."</td>";
echo"<td>".$row['name']."</td>";
echo"<td>".$row['email']."</td>";
echo"<td>".$row['mobile_no']."</td>";
echo"<td>".$row['course']."</td>";
echo"<td>".$row['address']."</td>";
echo"</tr>";
}
echo"</table>";
}
else
echo "record not found";
mysql_close($con);
?>
<table border=0>
<tr>
<td>Roll:</td>
<td><input type="text" name="roll"</td>
</tr>
<tr>
<td> Name:</td>
<td><input type="text" name="name"</td>
</tr>
<tr>
<td>Email:</td>
<td><input type="text" name="email"</td>
</tr>
<tr>
<td>Mobile_No:</td>
<td><input type="text" name="mobile_no"</td>
</tr>
<tr>
<td> Course:</td>
<td><input type="text" name="course"</td>
</tr>
<tr>
<td>Address:</td>
<td><input type="text" name="address"</td>
</tr>
<tr>
<td></td>
<td><input type="submit" value="update">
<input type="reset"></td>
</tr>
</center>
</table>
</form>
<h1><a style="float:left;"href="welcome2.php">Go to Result Dashboard</a></h1>
</body>
</html>