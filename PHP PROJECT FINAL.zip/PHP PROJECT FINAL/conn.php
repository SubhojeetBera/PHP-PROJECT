<?php
$servername="localhost";
$username="root";
$password="";
$db="college";
$conn=new mysqli($servername,$username,$password,$db);
if(!$conn){
die("Error on the connection".$conn->connect_error);
}
?>