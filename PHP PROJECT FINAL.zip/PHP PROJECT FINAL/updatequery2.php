<?php
$con=mysql_connect("localhost","root");
if(!$con)
{
die('Could not connect:'.mysql_error());
}
mysql_select_db("college",$con);
$sql="UPDATE class_result SET roll='$_POST[roll]',name='$_POST[name]',mod1='$_POST[mod1]',mod2='$_POST[mod2]',mod3='$_POST[mod3]',mod4='$_POST[mod4]',mod5='$_POST[mod5]',total='$_POST[total]',grade='$_POST[grade]' where roll='$_POST[roll]'";
if(!mysql_query($sql,$con))
{
die('Error:'.mysql_error());
}
echo"1 record updated";
mysql_close($con)
?>
<html><body><h1><a style="float:left;"href="welcome2.php">Go to Result Dashboard</a></h1>
</html></body>