<?php
$con=mysql_connect("localhost","root");
if(!$con)
{
die('could not connect.'.mysql_error());
}
mysql_select_db("college",$con);
$result=mysql_query("SELECT * FROM student_info where roll='$_POST[roll]'");
$num_rows=mysql_num_rows($result);
if($num_rows>=1)
{
echo "<table border='1'>
<tr>
<th>Roll</th>
<th>Name</th>
<th>Email</th>
<th>Mobile_No</th>
<th>Course</th>
<th>Address</th>
</tr>";
while($row=mysql_fetch_array($result))
{
echo"<tr>";
echo"<td>".$row['roll']."</td>";
echo"<td>".$row['name']."</td>";
echo"<td>".$row['email']."</td>";
echo"<td>".$row['mobile_no']."</td>";
echo"<td>".$row['course']."</td>";
echo"<td>".$row['address']."</td>";
echo"</tr>";
}
echo"</table>";
}
else
echo "record not found";
mysql_close($con);
?>
<html><body><a href="search3.php">Go bake to home page</a>
</body></html>