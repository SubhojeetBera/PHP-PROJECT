<?php
$con=mysql_connect("localhost","root");
if(!$con)
{
die('could cot connect:'.mysql_error());
}
mysql_select_db("college",$con);
$sql="DELETE FROM class_result WHERE roll=$_POST[roll]";
if(!mysql_query($sql,$con))
{
die('Error:'.mysql_error());
}
echo"record deleted sucessfully";
mysql_close($con)
?>
<html><body><h1><a style="float:left;"href="welcome2.php">Go to Result Dashboard</a></h1>
</html></body>