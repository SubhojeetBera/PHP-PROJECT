<?php
$con=mysql_connect("localhost","root");
if(!$con)
{
die('Could not connect:'.mysql_error());
}
mysql_select_db("college",$con);
$sql="INSERT INTO student_info(roll,name,email,mobile_no,course,address)VALUES('$_POST[roll]','$_POST[name]','$_POST[email]','$_POST[mobile_no]','$_POST[course]','$_POST[address]')";
if(!mysql_query($sql,$con))
{
die('Error:'.mysql_error());
}
echo"1 record added";
mysql_close($con)
?>
<html><body><a href="welcome.php">Go bake to home page</a>
</body></html>