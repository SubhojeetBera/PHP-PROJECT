<html>
<body style="background-image:url('1.jpg');background-repeat: no-repeat;
    background-size: cover;
    background-position:;
    width: 100%;
    height: 100%;">
<form action="insequery2.php" method="post">
<center>
<h1><center><font color=white><u>Insert Data</u></font></center></h1><br><br>
<table border=0>
<tr>
<th><font size=5 color=white>Roll:</font></th>
<td><input type="text" name="roll" required</td>
</tr>
<tr>
<th><font size=5 color=white>Name:</font></th>
<td><input type="text" name="name" required</td>
</tr>
<tr>
<th><font size=5 color=white>Module I:</font></th>
<td><input type="text" name="mod1" required</td>
</tr>
<tr>
<th><font size=5 color=white>Module II:</font></th>
<td><input type="text" name="mod2" required</td>
</tr>
<tr>
<th><font size=5 color=white>Module III:</font>:</th>
<td><input type="text" name="mod3" required</td>
</tr>
<tr>
<th><font size=5 color=white>Module IV:</font>:</th>
<td><input type="text" name="mod4" required</td>
</tr>
<tr>
<th><font size=5 color=white>Module V:</font>:</th>
<td><input type="text" name="mod5" required</td>
</tr>
<tr>
<th><font size=5 color=white>Total:</font>:</th>
<td><input type="text" name="total" required</td>
</tr>
<tr>
<th><font size=5 color=white>Grade:</font>:</th>
<td><input type="text" name="grade" required</td>
</tr>
<tr>
<td></td>
<th><input type="submit" value="Insert">
<input type="reset"></th>
</tr>
</center>
</form>
<h1><a style="float:left;"href="welcome2.php"><b style="color:white">Go to Result Dashboard</b></a></h1>
</body>
</html>