<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Dashboard - Client area</title>
    <link rel="stylesheet" href="dashb.css" />
</head>
<body background="1.jpg"  style="background-repeat:no-repeat;background-size:100% 100%">
    <div class="form" >
        <div class="header">
            <ul class="headerul">
                <li><div class="usericon"><img class="usericon" src="logo.jpg" alt="Girl in a jacket"></div></li>
                <li><div class="puser"><img src="rkms_logo.jpg"></div></li>
                <li><div class="empty"></div></li>
                <li style="float:right"><div ><img class="glogo" src="Screenshot-2021-02-10-at-1.59.13-PM.png"></div></li>
            </ul>       
	   </div>
<div class="c" style="background: green">
<ul>
    <li class="nav"><a href="display2.php">Display</a></li>
    <li class="nav"><a href="search2.php">Search</a></li>
    <li class="nav"><a href="insert2.php">Insert</a></li>
    <li class="nav"><a href="update2.php">Update</a></li>
    <li class="nav"><a href="delete2.php">Delete</a></li>
<li class="nav" style="float:right"><a href="index.html" class="logout"><input type="image"  class="logoutimg" src="ll.png" alt="Submit"></a></li>
        
</ul>
<h1><a href="welcome.php"><b style="color:white">GO TO STUDENT PAGE</b></a></h1>
</div>
</header>
<hr>
<div class="footer-continer" style="display: flex; flex-direction: row;padding-left: 36%;">
                <div class="f1" style="padding-right: 2%;"><p style="color:white"><b>Submitted By:</b>SUBHOJEET BERA</p></div>
                <div class="f2" style="padding-right: 2%;"><p style="color:white"><b>Roll:</b>P02202209C</p></div>
                <div class="f3" style="padding-right: 2%;"><p style="color:white"><b>Course:</b>CCPA</p></div>
</div>
<div class=copyr id="copyri" style="display: flex;justify-content: center;color:white">
<div>Copyright&#169; RKMSCC 2014</div>
</div>
</div>
<?php
session_start();
if(isset($_SESSION["user"]))
{
if((time()-$_SESSION['last_time'])>600)
{
header("location: logout.php");
}
else
{
$_SESSION['last_time']=time();
echo"<h1 align='center'>Welcome ".$_SESSION["user"]."</h1>";
echo "<h3 align='center'>Autometic Logout after one minute of inactive</h3>";
//echo"<p align='center'><a href='logout.php'>Logout</a></p>";
}
}
else
{
header('location: h.php');
}
?>

</body>
</html>