-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 14, 2022 at 05:26 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `college`
--
CREATE DATABASE IF NOT EXISTS `college` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `college`;

-- --------------------------------------------------------

--
-- Table structure for table `class_result`
--

CREATE TABLE IF NOT EXISTS `class_result` (
  `roll` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `mod1` varchar(10) NOT NULL,
  `mod2` varchar(11) NOT NULL,
  `mod3` varchar(11) NOT NULL,
  `mod4` varchar(11) NOT NULL,
  `mod5` varchar(10) NOT NULL,
  `total` varchar(30) NOT NULL,
  `grade` varchar(30) NOT NULL,
  PRIMARY KEY (`roll`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `class_result`
--

INSERT INTO `class_result` (`roll`, `name`, `mod1`, `mod2`, `mod3`, `mod4`, `mod5`, `total`, `grade`) VALUES
(11, 'sb', '10', '10', '10', '10', '10', '50', 'a'),
(12, 'SUBHOJEET BERA', '99', '99', '99', '99', '99', '495', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `user` varchar(20) NOT NULL,
  `pass` varchar(30) NOT NULL,
  `desig` varchar(30) NOT NULL,
  `last_time` int(30) NOT NULL,
  PRIMARY KEY (`user`),
  UNIQUE KEY `user` (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`user`, `pass`, `desig`, `last_time`) VALUES
('king', '2011', 'admin', 0),
('nilo', '2000', 'student', 0),
('samir', '2001', 'student', 0),
('sb', '321', 'Student', 1),
('sd', 'sd', 'Admin', 0),
('ss', 'ss', 'student', 0),
('subho', '1234', 'Admin', 1),
('subhojeet', '2022', 'student', 0);

-- --------------------------------------------------------

--
-- Table structure for table `student_info`
--

CREATE TABLE IF NOT EXISTS `student_info` (
  `roll` varchar(20) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `mobile_no` varchar(11) NOT NULL,
  `course` varchar(11) NOT NULL,
  `address` varchar(150) NOT NULL,
  PRIMARY KEY (`roll`),
  UNIQUE KEY `roll` (`roll`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_info`
--

INSERT INTO `student_info` (`roll`, `name`, `email`, `mobile_no`, `course`, `address`) VALUES
('09', 'Subhojeet Bera', 'subhojeetbera2001@gmail.com', '9330242830', 'CCPA', '12,narayan bhattacharya lane, sheoraphuli, Hooghly'),
('10', 'sb', 'subhojeetbera2001@gmail.com0', '9330242835', 'CCA', '12,narayan bhattacharya lane, sheoraphul'),
('88', 'g', 'gg', '7853678686', 'cca', 'gg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
